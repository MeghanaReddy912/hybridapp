package com.example.battery30;

public class globes {
    static boolean notif=false;

}
